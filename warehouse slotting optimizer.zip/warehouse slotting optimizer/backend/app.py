"""
Warehouse Slotting Optimizer – Flask Backend
=============================================
Endpoints
---------
POST /api/auth/register   – create account
POST /api/auth/login      – sign in, returns JWT
POST /api/auth/logout     – invalidate token (client-side)

GET  /api/skus            – list all SKUs for the session
POST /api/skus/upload     – parse uploaded CSV, return parsed rows
POST /api/skus/load       – commit parsed rows as active SKU set
POST /api/skus/reset      – regenerate built-in 150-SKU demo dataset

POST /api/optimize        – run greedy priority-queue slotting, return results
GET  /api/route           – compute pick-path for a random order
GET  /api/export/csv      – download slotting_results.csv
GET  /api/sample/<type>   – download sample CSV (sku | wh | ord)
"""

import heapq, math, random, hashlib, os, csv, io, time
from functools import wraps
from pathlib import Path

from flask import Flask, request, jsonify, send_file, send_from_directory, g
from flask_cors import CORS
import jwt

# ── app setup ───────────────────────────────────────────────────────────────
# The HTML file lives one folder above backend/
ROOT_DIR = Path(__file__).parent.parent

app = Flask(__name__, static_folder=None)
CORS(app, supports_credentials=True)


# ── serve the frontend ────────────────────────────────────────────────────────
@app.get("/")
def index():
    """Serve the warehouse optimizer HTML page."""
    return send_from_directory(ROOT_DIR, "warehouse-slotting-optimizer.html")

@app.get("/favicon.ico")
def favicon():
    return "", 204

SECRET = os.environ.get("WSO_SECRET", "wso-dev-secret-change-in-prod")
JWT_ALG = "HS256"
JWT_EXP  = 7 * 24 * 3600  # 1 week

# In-memory "database" keyed by email
_users: dict[str, dict] = {}   # {email: {name, hash, salt}}
_sessions: dict[str, dict] = {}  # {email: {skus, opt}}


# ── warehouse geometry (mirrors the JS constants) ───────────────────────────
COLS, ROWS = 16, 12
CATS = ["Electronics", "Apparel", "Grocery", "Tools", "Home"]
AI   = "ABCDEFGH"
BLOCKED = {(0,11),(7,5),(8,5),(15,6),(3,3),(12,0)}
DX, FY, DY = 284, 294, 330

def _px(c): return 20 + c*26 + (c >> 1)*14
def _py(r): return 20 + (ROWS - 1 - r)*22
def _axp(c): return 20 + (c >> 1)*66 + 59

def _build_slots():
    slots = []
    for c in range(COLS):
        for r in range(ROWS):
            p = c >> 1
            x = _px(c) + 11
            y = _py(r) + 9
            ax = _axp(c)
            d = (abs(ax - DX) + FY - y + DY - FY) * 0.12
            slots.append({
                "i": len(slots),
                "c": c, "r": r, "p": p,
                "id": f"{AI[p]}-{'R' if c % 2 else 'L'}-{str(r+1).zfill(2)}",
                "blocked": (c, r) in BLOCKED,
                "x": x, "y": y, "ax": ax, "d": d,
            })
    return slots

SLOTS = _build_slots()
FREE_SLOTS = [s for s in SLOTS if not s["blocked"]]


# ── helpers ──────────────────────────────────────────────────────────────────
def _hash_pw(password: str, salt: str) -> str:
    raw = f"{salt}:{password}".encode()
    return hashlib.sha256(raw).hexdigest()

def _make_token(email: str) -> str:
    payload = {"sub": email, "exp": int(time.time()) + JWT_EXP}
    return jwt.encode(payload, SECRET, algorithm=JWT_ALG)

def _decode_token(token: str):
    return jwt.decode(token, SECRET, algorithms=[JWT_ALG])

def require_auth(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Unauthorized"}), 401
        try:
            payload = _decode_token(auth[7:])
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401
        email = payload["sub"]
        if email not in _users:
            return jsonify({"error": "User not found"}), 401
        g.email = email
        if email not in _sessions:
            _sessions[email] = {"skus": None, "opt": None}
        g.session = _sessions[email]
        return fn(*args, **kwargs)
    return wrapper

def _session_skus(email: str):
    """Return the SKU list for the user, generating demo data if needed."""
    sess = _sessions.setdefault(email, {"skus": None, "opt": None})
    if sess["skus"] is None:
        sess["skus"] = _gen_skus()
        sess["opt"] = None
    return sess["skus"]

def _max_weight(slot):
    return 80 if slot["r"] < 4 else 40

def _max_height(slot):
    return 120 if slot["r"] < 4 else 70

def _feasible(slot, sku):
    return (
        not slot["blocked"]
        and sku["w"] <= _max_weight(slot)
        and sku["h"] <= _max_height(slot)
        and max(sku["l"], sku["wd"]) <= 100
        and sku["l"] * sku["wd"] * sku["h"] <= 1_000_000
    )

def _tiers(skus):
    ordered = sorted(skus, key=lambda k: -k["f"])
    n = len(ordered)
    for i, k in enumerate(ordered):
        k["pri"] = "High" if i < n * 0.2 else ("Medium" if i < n * 0.5 else "Low")


# ── demo data generator (mirrors JS gen()) ───────────────────────────────────
_NAMES = ["Bolt kit","Wireless mouse","Rain jacket","Rice 10kg",
          "Drill bit set","Desk lamp","Cable pack","Tote bag"]

def _gen_skus(seed: int = 11) -> list[dict]:
    rng = random.Random(seed)
    n = 150

    def rnd(): return rng.random()

    skus = []
    for i in range(n):
        skus.append({
            "id":  f"SKU-{1001+i}",
            "name": f"{_NAMES[i % 8]} {i+1}",
            "cat":  CATS[i % 5],
            "f":    1 + round(40 / pow(i+1, 0.7)),
            "w":    round(1 + rnd() * (62 if i % 9 == 0 else 30), 1),
            "l":    15 + round(rnd() * 60),
            "wd":   15 + round(rnd() * 50),
            "h":    10 + round(rnd() * 50),
            "q":    20 + round(rnd() * 200),
        })

    # shuffle frequencies
    for i in range(n-1, 0, -1):
        j = int(rnd() * (i+1))
        skus[i]["f"], skus[j]["f"] = skus[j]["f"], skus[i]["f"]

    # random initial slot assignment
    free = [s["i"] for s in FREE_SLOTS]
    for i in range(len(free)-1, 0, -1):
        j = int(rnd() * (i+1))
        free[i], free[j] = free[j], free[i]

    for i, k in enumerate(skus):
        k["o"] = free[i]
        k["n"] = None

    _tiers(skus)
    return skus


# ── slotting optimizer (priority queue + greedy) ─────────────────────────────
def _optimize(skus: list[dict], cfg: dict) -> dict:
    _tiers(skus)

    # max-heap via negating frequency
    heap = [(-k["f"], i) for i, k in enumerate(skus)]
    heapq.heapify(heap)

    slot_order = sorted(FREE_SLOTS, key=lambda s: s["d"])
    used: set[int] = set()
    bad = 0

    while heap:
        _, ki = heapq.heappop(heap)
        k = skus[ki]
        placed = None
        for s in slot_order:
            if s["i"] not in used and _feasible(s, k):
                placed = s
                break
        if placed is None:
            for s in slot_order:
                if s["i"] not in used:
                    placed = s
                    bad += 1
                    break
        used.add(placed["i"])
        k["n"] = placed["i"]

    def _dist(k, which):
        return SLOTS[k["o"] if which == "o" else k["n"]]["d"]

    def _tot(which):
        return sum(k["f"] * 2 * _dist(k, which) for k in skus) / 1000

    def _viol(which):
        return sum(1 for k in skus if not _feasible(SLOTS[k["o"] if which == "o" else k["n"]], k))

    a = _tot("o")
    b = _tot("n")
    sv = (a - b) / a * 100 if a else 0

    return {
        "a": round(a, 3),
        "b": round(b, 3),
        "sv": round(sv, 2),
        "thr": round(sv * 0.78),
        "viol": _viol("n"),
        "util": round(len(skus) / len(FREE_SLOTS) * 100),
        "bad_placements": bad,
    }


# ── pick-path routing ─────────────────────────────────────────────────────────
def _route(order_skus: list[dict], which: str) -> dict:
    """Compute aisle-sweep pick route. which='o' or 'n'."""
    stops = sorted(
        [SLOTS[k["o"] if which == "o" else k["n"]] for k in order_skus],
        key=lambda s: (s["p"], -s["y"] if s["p"] % 2 else s["y"])
    )
    pts = [[DX, DY], [DX, FY]]
    pa = -1
    visits = 0
    for s in stops:
        if s["p"] != pa:
            pts.append([s["ax"], FY])
            visits += 1
            pa = s["p"]
        pts += [[s["ax"], s["y"]], [s["x"], s["y"]], [s["ax"], s["y"]]]
    pts += [[pts[-1][0], FY], [DX, FY], [DX, DY]]

    L = sum(abs(pts[i][0]-pts[i-1][0]) + abs(pts[i][1]-pts[i-1][1])
            for i in range(1, len(pts)))
    m = L * 0.12
    return {
        "pts": pts,
        "stops": [s["i"] for s in stops],
        "m": round(m, 2),
        "st": visits,
        "t": round((m / 1.2 + len(order_skus) * 20) / 60, 2),
    }


# ── auth routes ───────────────────────────────────────────────────────────────
@app.post("/api/auth/register")
def register():
    data = request.json or {}
    name  = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    pw    = data.get("password", "")

    if not name:
        return jsonify({"error": "Name is required."}), 400
    import re
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        return jsonify({"error": "Invalid email address."}), 400
    if len(pw) < 8:
        return jsonify({"error": "Password must be at least 8 characters."}), 400
    if email in _users:
        return jsonify({"error": "An account with this email already exists."}), 409

    salt = os.urandom(8).hex()
    _users[email] = {"name": name, "salt": salt, "hash": _hash_pw(pw, salt)}
    _sessions[email] = {"skus": None, "opt": None}
    token = _make_token(email)
    return jsonify({"token": token, "name": name, "email": email}), 201


@app.post("/api/auth/login")
def login():
    data  = request.json or {}
    email = data.get("email", "").strip().lower()
    pw    = data.get("password", "")

    user = _users.get(email)
    if not user or _hash_pw(pw, user["salt"]) != user["hash"]:
        return jsonify({"error": "Incorrect email or password."}), 401

    token = _make_token(email)
    return jsonify({"token": token, "name": user["name"], "email": email})


@app.post("/api/auth/logout")
@require_auth
def logout():
    # JWT is stateless; client just drops the token.
    return jsonify({"ok": True})


# ── SKU routes ────────────────────────────────────────────────────────────────
@app.get("/api/skus")
@require_auth
def list_skus():
    skus = _session_skus(g.email)
    opt  = g.session.get("opt")
    return jsonify({"skus": skus, "opt": opt, "slots": SLOTS})


@app.post("/api/skus/reset")
@require_auth
def reset_skus():
    g.session["skus"] = _gen_skus()
    g.session["opt"]  = None
    return jsonify({"count": len(g.session["skus"]), "message": "Demo dataset regenerated."})


@app.post("/api/skus/upload")
@require_auth
def upload_skus():
    """Parse a CSV file and return validation info without committing."""
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded."}), 400
    f = request.files["file"]
    if not f.filename.lower().endswith(".csv"):
        return jsonify({"error": "Only .csv files are supported."}), 400

    content = f.read().decode("utf-8", errors="replace")
    lines = [l.split(",") for l in content.strip().splitlines()]
    if not lines:
        return jsonify({"error": "Empty file."}), 400

    headers = [h.strip().lower() for h in lines[0]]
    body    = [[c.strip() for c in row] for row in lines[1:]]

    REQUIRED = ["sku_id","sku_name","category","quantity","length","width","height","weight","pick_frequency"]
    missing  = [h for h in REQUIRED if h not in headers]
    empty    = sum(1 for row in body for c in row if c == "")
    numeric_err = 0
    for row in body:
        for h in ["quantity","length","width","height","weight","pick_frequency"]:
            if h in headers:
                val = row[headers.index(h)] if headers.index(h) < len(row) else ""
                try: float(val)
                except: numeric_err += 1

    return jsonify({
        "headers": headers,
        "row_count": len(body),
        "missing_columns": missing,
        "empty_values": empty,
        "numeric_errors": numeric_err,
        "preview": body[:5],
        "valid": not missing and not numeric_err and len(body) > 0,
    })


@app.post("/api/skus/load")
@require_auth
def load_skus():
    """Commit a previously validated CSV payload as the active SKU set."""
    data    = request.json or {}
    headers = [h.lower() for h in data.get("headers", [])]
    body    = data.get("body", [])

    def g_(row, col):
        if col in headers and headers.index(col) < len(row):
            return row[headers.index(col)]
        return ""

    if len(body) > len(FREE_SLOTS):
        return jsonify({"error": f"Too many SKUs. Warehouse has {len(FREE_SLOTS)} usable slots."}), 400

    free = [s["i"] for s in FREE_SLOTS]
    skus = []
    for i, row in enumerate(body):
        skus.append({
            "id":   g_(row, "sku_id"),
            "name": g_(row, "sku_name") or g_(row, "sku_id"),
            "cat":  g_(row, "category") or "Other",
            "f":    float(g_(row, "pick_frequency") or 1),
            "w":    float(g_(row, "weight") or 1),
            "l":    float(g_(row, "length") or 20),
            "wd":   float(g_(row, "width") or 20),
            "h":    float(g_(row, "height") or 20),
            "q":    float(g_(row, "quantity") or 0),
            "o":    free[i],
            "n":    None,
        })
    _tiers(skus)
    g.session["skus"] = skus
    g.session["opt"]  = None
    return jsonify({"count": len(skus), "message": f"{len(skus)} SKUs loaded. Run the optimizer."})


# ── optimizer route ───────────────────────────────────────────────────────────
@app.post("/api/optimize")
@require_auth
def optimize():
    skus = _session_skus(g.email)
    cfg  = request.json or {}

    # Apply optional constraint overrides from the request body
    global_cfg = {
        "wFloor":  float(cfg.get("wFloor", 80)),
        "wUpper":  float(cfg.get("wUpper", 40)),
        "vol":     float(cfg.get("vol", 1.0)),
        "blocked": cfg.get("blocked", ""),
    }

    # Filter out blocked aisle if specified
    effective_free = [
        s for s in FREE_SLOTS
        if not (global_cfg["blocked"] and AI[s["p"]] == global_cfg["blocked"])
    ]

    def _feas_cfg(slot, sku):
        mw = global_cfg["wFloor"] if slot["r"] < 4 else global_cfg["wUpper"]
        mh = 120 if slot["r"] < 4 else 70
        return (
            not slot["blocked"]
            and sku["w"] <= mw
            and sku["h"] <= mh
            and max(sku["l"], sku["wd"]) <= 100
            and sku["l"] * sku["wd"] * sku["h"] <= 1_000_000 * global_cfg["vol"]
        )

    _tiers(skus)
    heap = [(-k["f"], i) for i, k in enumerate(skus)]
    heapq.heapify(heap)
    slot_order = sorted(effective_free, key=lambda s: s["d"])
    used: set[int] = set()
    bad = 0

    while heap:
        _, ki = heapq.heappop(heap)
        k = skus[ki]
        placed = next((s for s in slot_order if s["i"] not in used and _feas_cfg(s, k)), None)
        if placed is None:
            placed = next((s for s in slot_order if s["i"] not in used), None)
            bad += 1
        if placed:
            used.add(placed["i"])
            k["n"] = placed["i"]

    def _dist(k, which):
        idx = k["o"] if which == "o" else k["n"]
        return SLOTS[idx]["d"] if idx is not None else 0

    def _tot(which):
        return sum(k["f"] * 2 * _dist(k, which) for k in skus) / 1000

    def _viol(which):
        return sum(1 for k in skus
                   if not _feas_cfg(SLOTS[k["o"] if which == "o" else (k["n"] or k["o"])], k))

    a = _tot("o")
    b = _tot("n")
    sv = (a - b) / a * 100 if a else 0

    opt = {
        "a": round(a, 3),
        "b": round(b, 3),
        "sv": round(sv, 2),
        "thr": round(sv * 0.78),
        "viol": _viol("n"),
        "util": round(len(skus) / len(effective_free) * 100) if effective_free else 0,
        "bad_placements": bad,
    }
    g.session["opt"] = opt
    return jsonify({"opt": opt, "skus": skus})


# ── pick-path route ───────────────────────────────────────────────────────────
@app.get("/api/route")
@require_auth
def get_route():
    skus = _session_skus(g.email)
    n    = min(int(request.args.get("n", 8)), len(skus))
    opt  = g.session.get("opt")

    sample = random.sample(skus, n)
    before = _route(sample, "o")
    after  = _route(sample, "n") if opt else before

    red = (before["m"] - after["m"]) / before["m"] * 100 if before["m"] else 0
    return jsonify({
        "order": [k["id"] for k in sample],
        "before": before,
        "after": after,
        "reduction_pct": round(red, 2),
    })


# ── export ────────────────────────────────────────────────────────────────────
@app.get("/api/export/csv")
@require_auth
def export_csv():
    skus = _session_skus(g.email)
    opt  = g.session.get("opt")
    if not opt:
        return jsonify({"error": "Run the optimizer first."}), 400

    buf = io.StringIO()
    w   = csv.writer(buf)
    w.writerow(["sku","original_location","optimized_location",
                "original_distance_m","new_distance_m","savings"])
    for k in skus:
        o_slot = SLOTS[k["o"]]
        n_slot = SLOTS[k["n"]] if k["n"] is not None else o_slot
        sv = f"{round((o_slot['d'] - n_slot['d']) / o_slot['d'] * 100, 1)}%" if o_slot["d"] else "0%"
        w.writerow([k["id"], o_slot["id"], n_slot["id"],
                    round(o_slot["d"], 2), round(n_slot["d"], 2), sv])

    buf.seek(0)
    return send_file(
        io.BytesIO(buf.getvalue().encode()),
        mimetype="text/csv",
        as_attachment=True,
        download_name="slotting_results.csv",
    )


# ── sample CSV downloads ──────────────────────────────────────────────────────
SAMPLES = {
    "sku": (
        "sku_id,sku_name,category,quantity,length,width,height,weight,pick_frequency,demand_rate\n"
        "SKU-2001,Cable pack,Electronics,120,30,20,10,2.5,35,4.1\n"
        "SKU-2002,Rice 10kg,Grocery,80,40,25,15,10,12,1.8\n"
    ),
    "wh": (
        "aisle,rack,bay,slot,max_weight,slot_dims,coordinates\n"
        "A,1,1,1,80,100x100x120,0;0\n"
    ),
    "ord": (
        "order_id,sku_id,quantity,order_date,pick_location\n"
        "ORD-1,SKU-2001,2,2026-09-01,A-L-01\n"
    ),
}

@app.get("/api/sample/<type_>")
@require_auth
def sample_csv(type_):
    if type_ not in SAMPLES:
        return jsonify({"error": "Unknown sample type. Use: sku, wh, ord"}), 404
    buf = io.BytesIO(SAMPLES[type_].encode())
    return send_file(buf, mimetype="text/csv", as_attachment=True,
                     download_name=f"sample_{type_}.csv")


# ── health ────────────────────────────────────────────────────────────────────
@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "users": len(_users)})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
