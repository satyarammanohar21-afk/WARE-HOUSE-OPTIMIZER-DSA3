"""
Quick smoke test for the Warehouse Slotting Optimizer API.
Run with: python test_api.py  (while app.py is running on port 5000)
"""
import requests, json, sys

BASE = "http://localhost:5000/api"
HDR  = {}

def p(label, r):
    ok = r.status_code < 300
    sym = "[OK]" if ok else "[FAIL]"
    print(f"  {sym} [{r.status_code}] {label}")
    if not ok:
        print("    ", r.text[:200])
    return r

def h(token):
    return {"Authorization": f"Bearer {token}"}

print("\n=== Auth ===")
r = p("register", requests.post(f"{BASE}/auth/register", json={
    "name": "Test User", "email": "test@example.com", "password": "password123"
}))
if r.status_code not in (201, 409):
    sys.exit(1)

r = p("login", requests.post(f"{BASE}/auth/login", json={
    "email": "test@example.com", "password": "password123"
}))
token = r.json().get("token")
if not token:
    print("Login failed – aborting."); sys.exit(1)

print("\n=== SKUs ===")
p("list SKUs", requests.get(f"{BASE}/skus", headers=h(token)))
p("reset SKUs", requests.post(f"{BASE}/skus/reset", headers=h(token)))

print("\n=== Optimizer ===")
r = p("optimize (default cfg)", requests.post(f"{BASE}/optimize", headers=h(token), json={}))
opt = r.json().get("opt", {})
print(f"    Before={opt.get('a')} km  After={opt.get('b')} km  Saved={opt.get('sv')}%")

print("\n=== Route ===")
r = p("pick route n=8", requests.get(f"{BASE}/route?n=8", headers=h(token)))
rt = r.json()
print(f"    Before={rt.get('before',{}).get('m')} m  After={rt.get('after',{}).get('m')} m")

print("\n=== Export ===")
r = p("export CSV", requests.get(f"{BASE}/export/csv", headers=h(token)))
if r.ok:
    lines = r.text.strip().splitlines()
    print(f"    CSV rows: {len(lines)-1} (header + data)")

print("\n=== Sample CSVs ===")
for t in ("sku", "wh", "ord"):
    p(f"sample/{t}", requests.get(f"{BASE}/sample/{t}", headers=h(token)))

print("\n=== Health ===")
p("health", requests.get(f"{BASE}/health"))

print("\nAll tests done.\n")
